<?php
/**
 * Plugin Name: urZONE PVE - Demo Plan
 * Description: Adds [urzone_pve_demo]: front-page demo for any logged-in user, time-limited, with automatic deletion of every demo instance. Requires the urZONE PVE core plugin.
 * Version:     1.0.0
 * Author:      Osiris Simmons (Osiris83)
 * Author URI:  https://urzone.org
 * License:     GPL-2.0-or-later
 * License URI: https://www.gnu.org/licenses/gpl-2.0.html
 */

defined( 'ABSPATH' ) || exit;

/*
 * Demo settings live in wp-config.php (all optional, defaults shown):
 *
 * define( 'URZONE_PROXMOX_DEMO_MINUTES', 60 );           // length of one demo
 * define( 'URZONE_PROXMOX_DEMO_WARN_MINUTES', 10 );      // warning before it ends (0 = off)
 * define( 'URZONE_PROXMOX_DEMO_MAX_INSTANCES', 2 );      // instances per demo
 * define( 'URZONE_PROXMOX_DEMO_COOLDOWN_MINUTES', 0 );   // wait before the same user can start another demo
 * define( 'URZONE_PROXMOX_DEMO_BRIDGE', '' );            // e.g. an isolated bridge for demo guests
 */

/* Plan definition: open to every logged-in user; instance limit comes from URZONE_PROXMOX_DEMO_MAX_INSTANCES. */
add_filter(
	'urzone_pve_plans',
	static function ( $plans ) {
		$max = defined( 'URZONE_PROXMOX_DEMO_MAX_INSTANCES' ) ? (int) URZONE_PROXMOX_DEMO_MAX_INSTANCES : 2;

		$plans['demo'] = array(
			'label' => 'Demo',
			'limit' => max( 1, $max ),
			'admin' => false,
			'demo'  => true,
		);

		return $plans;
	}
);

/* Shortcodes: [urzone_pve_demo] and [urzone-pve-demo] */
add_action(
	'init',
	static function () {
		foreach ( array( 'urzone_pve_demo', 'urzone-pve-demo' ) as $tag ) {
			add_shortcode(
				$tag,
				static function ( $atts ) use ( $tag ) {
					if ( ! function_exists( 'urzone_pve_render' ) ) {
						return '<p>The urZONE PVE core plugin must be active.</p>';
					}

					return urzone_pve_render( $atts, 'demo', $tag );
				}
			);
		}
	}
);
